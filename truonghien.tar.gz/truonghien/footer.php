<div id="footer">
    <!-- Please leave this line intact -->
    <p>Template design <a href="http://google.com.vn">Six Shooter Media</a><br />
    <!-- you can delete below here -->
    <?php the_time('Y'); ?> <?php bloginfo('name'); ?><br />
    <a href="<?php bloginfo('rss2_url'); ?>">Grab the feed</a>
    </p>
</div>

</div>

<?php  wp_footer(); ?>

</body>
</html>